//tutorial from https://www.youtube.com/watch?v=kwcillcWOg0&t=650s
// by CodingTrain 

// The video
let video;
// For displaying the label
let label = "waiting...";
// The classifier
let classifier;
let modelURL ='https://teachablemachine.withgoogle.com/models/gkJtUhbZj/';
let labels = [
  "Lucie",
  "Bunny",
  "Headphone",
  "Consoler",
  "Joy-Con-Red",
  "Joy-Con-Blue",
];
let preLabel;
let songs=[];
// STEP 1: Load the model!
function preload() {
  classifier = ml5.imageClassifier(modelURL + "model.json");
  songs[0]=loadSound("Headphone.mp3");
  songs[1]=loadSound("bunny.mp3");
  songs[2]=loadSound("consoler.mp3");
  songs[3]=loadSound("joycon.mp3");
  songs[4]=loadSound("lucie.mp3");
  songs[5]=loadSound("Headphone.mp3");
}

function setup() {
  createCanvas(640, 520);
  // Create the video
  video = createCapture(VIDEO);
  video.hide();
  // STEP 2: Start classifying
  classifyVideo();
  textAlign(CENTER);
  textSize(25)
}

// STEP 2 classify the videeo!
function classifyVideo() {
  classifier.classify(video, gotResults);
}

function draw() {
  background(255);
  // label="Bunny"

  // Draw the video
  image(video, 0, 0,width,width * video.height / video.width);
  if (preLabel != label) {
    if (label == labels[0]) {
      for(let i =0;i<songs.lenght;i++){
        songs[i].stop()
      }
      songs[0].loop();
    } else if (label == labels[1]) {
      for(let i =0;i<songs.lenght;i++){
        songs[i].stop()
      }
            songs[1].loop();

    } else if (label == labels[2]) {
      for(let i =0;i<songs.lenght;i++){
        songs[i].stop()
      }
            songs[2].loop();

    } else if (label == labels[3]) {
      for(let i =0;i<songs.lenght;i++){
        songs[i].stop()
      }
            songs[3].loop();

    } else if (label == labels[4]) {
      for(let i =0;i<songs.lenght;i++){
        songs[i].stop()
      }
            songs[4].loop();

    } else {
      for(let i =0;i<songs.lenght;i++){
        songs[i].stop()
      }
            songs[5].loop();
    }
  }
  console.log(label);
  
  preLabel = label;
}

// STEP 3: Get the classification!
function gotResults(error, results) {
  // Something went wrong!
  if (error) {
    console.error(error);
    return;
  }
  // Store the label and classify again!
  label = results[0].label;
  classifyVideo();
}

