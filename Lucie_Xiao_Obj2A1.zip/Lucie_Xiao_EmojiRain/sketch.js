
//tutorial from https://www.youtube.com/watch?v=kwcillcWOg0&t=650s
// by CodingTrain 

// The video
let video;
// For displaying the label
let label = "waiting...";
// The classifier
let classifier;
let modelURL ='https://teachablemachine.withgoogle.com/models/gkJtUhbZj/';
let labels = [
  "Lucie",
  "Bunny",
  "Headphone",
  "Consoler",
  "Joy-Con-Red",
  "Joy-Con-Blue",
];
let preLabel;
let emojis=[];
// STEP 1: Load the model!
function preload() {
  classifier = ml5.imageClassifier(modelURL + "model.json");
}

function setup() {
  createCanvas(640, 520);
  // Create the video
  video = createCapture(VIDEO);
  video.hide();
  // STEP 2: Start classifying
  classifyVideo();
  textAlign(CENTER);
  textSize(25)
}

// STEP 2 classify the videeo!
function classifyVideo() {
  classifier.classify(video, gotResults);
}

function draw() {
  background(255);
  // label="Consoler"

  // Draw the video
  image(video, 0, 0,width,width * video.height / video.width);
  if (preLabel != label) {
    if (label == labels[0]) {
      for (let i = 0; i < 100; i++) {
        emojis[i] = new Emoji("🦄");
      }
    } else if (label == labels[1]) {
      for (let i = 0; i < 100; i++) {
        emojis[i] = new Emoji("🥰");
      }
    } else if (label == labels[2]) {
      for (let i = 0; i < 100; i++) {
        emojis[i] = new Emoji("😊");
      }
    } else if (label == labels[3]) {
      for (let i = 0; i < 100; i++) {
        emojis[i] = new Emoji("🥳");
      }
    } else if (label == labels[4]) {
      for (let i = 0; i < 100; i++) {
        emojis[i] = new Emoji("🎸");
      }
    } else {
      for (let i = 0; i < 100; i++) {
        emojis[i] = new Emoji("🌈");
      }
    }
  }
  // console.log(label);
  for (let i = 0; i < 100; i++) {
      emojis[i].update();
      emojis[i].display();
      }  
  preLabel = label;
}

// STEP 3: Get the classification!
function gotResults(error, results) {
  // Something went wrong!
  if (error) {
    console.error(error);
    return;
  }
  // Store the label and classify again!
  label = results[0].label;
  classifyVideo();
}
class Emoji {
  constructor(emoji) {
    this.emoji = emoji;
    this.x = random(width);
    this.y = random(-10, 0);
    this.speed = random(10, 2);
    this.a = 0.1;
  }
  update() {
    this.y += this.speed;
    this.speed += this.a;
    if (this.y > height) {
      this.y = 0;
      this.speed = random(10, 2);
    }
  }
  display() {
    text(this.emoji, this.x, this.y);
  }
}
